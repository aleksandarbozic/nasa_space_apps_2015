#include "stdafx.h"

#include <iostream>
#include <string>
#include <vector>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/legacy/legacy.hpp>

using namespace cv; 

int main( int argc, char** argv )
{
        if( argc != 3 ) return 1;

        Mat ImageTemple = imread(argv[1], CV_LOAD_IMAGE_GRAYSCALE ); 
        if( !ImageTemple.data )
                return 2; // error

        Mat Image = imread(argv[2], CV_LOAD_IMAGE_GRAYSCALE ); 
        if( !Image.data )
                return 3; // error

        std::vector<KeyPoint> keypointsImageTemple;
    Mat descriptorsImageTemple;
    std::vector<DMatch> matches;
    

    SurfFeatureDetector detector(1000); 

    detector.detect( ImageTemple, keypointsImageTemple );

        int maxy = 3;
        int maxx = 3;

        Mat Draw_mat = imread(argv[2], 1 ); 

        for( int y = 0; y < maxy; y++ )
                for( int x = 0; x < maxx; x++ )
                {
                        
                        // FREAK extractor(true, true, 22, 4, std::vector<int>());
                        FREAK extractor;
                       
                        BruteForceMatcher<Hamming> matcher;

                        std::vector<KeyPoint> keypointsImage;
                        Mat descriptorsImage;
                        CvRect Rect = cvRect( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) ), 
                                2 * ( Image.cols / ( maxx + 1) ), 2 * ( Image.rows / ( maxy + 1) ) );
                        Mat ImageROI( Image, Rect );

                        detector.detect( ImageROI, keypointsImage );
                
                        extractor.compute( ImageTemple, keypointsImageTemple, descriptorsImageTemple );
                        extractor.compute( ImageROI, keypointsImage, descriptorsImage );

                        matcher.match( descriptorsImageTemple, descriptorsImage, matches); 
                        
                        for (int i = 0; i < matches.size(); i++ )
                        {
                                if( matches[i].distance > 150 )
                                {
                                        matches.erase (matches.begin() + i);
                                }
                        }
        
                        std::vector<Point2f> obj;
                        std::vector<Point2f> scene; 
                        for( int i = 0; i < matches.size(); i++ )
                        {               
                                obj.push_back( keypointsImageTemple[ matches[i].queryIdx ].pt );
                                scene.push_back( keypointsImage[ matches[i].trainIdx ].pt );
                        }                       Mat H = findHomography( obj, scene, CV_RANSAC );                        std::vector<Point2f> obj_corners(4);
                        obj_corners[0] = cvPoint(0,0); obj_corners[1] = cvPoint( ImageTemple.cols, 0 );
                        obj_corners[2] = cvPoint( ImageTemple.cols, ImageTemple.rows ); obj_corners[3] = cvPoint( 0, ImageTemple.rows );
                        std::vector<Point2f> scene_corners(4);

                        perspectiveTransform( obj_corners, scene_corners, H);

                        //-- Draw lines between the corners (the mapped object in the scene - image_2 )
                        line( Draw_mat, scene_corners[0] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), scene_corners[1] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), Scalar(0, 255, 0), 4 );
                        line( Draw_mat, scene_corners[1] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), scene_corners[2] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), Scalar( 0, 255, 0), 4 );
                        line( Draw_mat, scene_corners[2] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), scene_corners[3] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), Scalar( 0, 255, 0), 4 );
                        line( Draw_mat, scene_corners[3] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), scene_corners[0] + Point2f( x * ( Image.cols / ( maxx + 1) ), y * ( Image.rows / ( maxy + 1) )), Scalar( 0, 255, 0), 4 );      
                        
                }
        imwrite("draw_mat.jpeg", Draw_mat);
        return 0;
}